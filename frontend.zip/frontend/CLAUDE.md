# OlasApp - Frontend

## Descripción del Proyecto

OlasApp es una aplicación web moderna para generar reportes de surf inteligentes usando inteligencia artificial. La aplicación combina datos meteorológicos, información de mareas, viento y oleaje para crear reportes precisos y personalizados.

## Stack Tecnológico

- **Framework**: Astro v5.13.9
- **Styling**: Tailwind CSS v4.1.13
- **Icons**: Lucide Astro
- **Language**: TypeScript
- **Build Tool**: Vite
- **Package Manager**: npm

## Estructura del Proyecto

```
frontend/
├── src/
│   ├── components/
│   │   ├── Header.astro           # Navegación principal y botón de login
│   │   ├── Hero.astro             # Sección principal con explicación
│   │   ├── Footer.astro           # Información de contacto
│   │   ├── DatePicker.astro       # Selector de fechas para reportes
│   │   ├── LocationSearch.astro   # Buscador de spots de surf
│   │   ├── ReportForm.astro       # Formulario principal de generación
│   │   ├── LoadingSpinner.astro   # Estados de carga y skeleton
│   │   ├── RatingFeedback.astro   # Sistema de calificación por estrellas
│   │   └── LoginModal.astro       # Modal de autenticación
│   ├── layouts/
│   │   └── Layout.astro           # Layout base con meta tags
│   ├── pages/
│   │   └── index.astro            # Página principal
│   └── styles/
│       └── global.css             # Estilos globales de Tailwind
├── public/                        # Archivos estáticos
├── astro.config.mjs              # Configuración de Astro
├── tailwind.config.js            # Configuración de Tailwind
├── tsconfig.json                 # Configuración de TypeScript
└── package.json                  # Dependencias y scripts
```

## Características Principales

### 🌊 Temática Marina
- Gradientes azules y cian que evocan el océano
- Iconografía relacionada con el surf y el mar
- Diseño moderno y limpio

### 📱 Responsive Design
- Totalmente adaptable a móviles, tablets y desktop
- Navegación optimizada para pantallas táctiles
- Grid layouts que se adaptan al tamaño de pantalla

### 🎯 Funcionalidades Core

#### 1. Generación de Reportes
- **Selector de ubicación**: Autocompletado con spots populares de surf
- **Selector de fechas**: Limitado a 7 días hacia adelante
- **Procesamiento IA**: Simulación de análisis meteorológico
- **Reportes detallados**: Condiciones de oleaje, viento, marea y recomendaciones

#### 2. Sistema de Feedback
- **Calificación por estrellas**: Sistema de 1-5 estrellas interactivo
- **Comentarios**: Campo opcional para feedback detallado
- **Validación**: Requiere calificación mínima para enviar
- **Confirmación visual**: Mensaje de éxito tras envío

#### 3. Autenticación
- **Modal de login/registro**: Interfaz moderna y accesible
- **Alternancia**: Cambio fluido entre login y registro
- **Estado visual**: Indicador de usuario logueado en header
- **Validación de formularios**: Campos requeridos y validación de email

#### 4. Estados de Carga
- **Spinner animado**: Con mensaje de procesamiento IA
- **Skeleton loader**: Para resultados de reportes
- **Transiciones suaves**: Entre estados de la aplicación

### 🎨 Componentes Reutilizables

- **Header**: Navegación sticky con logo y botón de login
- **Hero**: Sección explicativa con cards informativas
- **DatePicker**: Selector de fechas con validaciones
- **LocationSearch**: Buscador con autocompletado
- **LoadingSpinner**: Estados de carga unificados
- **RatingFeedback**: Sistema de calificación completo
- **LoginModal**: Autenticación con dual-mode
- **Footer**: Información de contacto y redes sociales

## Scripts Disponibles

```bash
# Desarrollo
npm run dev

# Build de producción
npm run build

# Preview de build
npm run preview

# Type checking
npm run astro check
```

## Configuración de Desarrollo

### Instalación
```bash
npm install
```

### Desarrollo Local
```bash
npm run dev
```
La aplicación estará disponible en `http://localhost:4321/`

### Build de Producción
```bash
npm run build
```

## Características Técnicas

### Performance
- **Astro Islands**: Hidratación selectiva de componentes
- **Zero JS por defecto**: Solo carga JavaScript cuando es necesario
- **Optimización de imágenes**: Lazy loading automático
- **CSS optimizado**: Purging automático de estilos no utilizados

### Accesibilidad
- **Semantic HTML**: Estructura semántica correcta
- **ARIA labels**: Etiquetas para lectores de pantalla
- **Focus management**: Navegación por teclado
- **Color contrast**: Cumple estándares WCAG

### SEO
- **Meta tags**: Configuración completa en Layout
- **Structured data**: Markup semántico
- **OpenGraph**: Tags para redes sociales
- **Performance**: Core Web Vitals optimizados

## Integración con Backend

La aplicación está preparada para integrarse con una API backend:

```typescript
// Ejemplo de integración API
const generateReport = async (location: string, date: string) => {
  const response = await fetch('/api/reports', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ location, date })
  });
  return response.json();
};
```

## Próximas Mejoras

- [ ] Integración con API real de datos meteorológicos
- [ ] Sistema de autenticación JWT
- [ ] Base de datos de reportes guardados
- [ ] Notificaciones push para condiciones favorables
- [ ] Modo offline con Service Workers
- [ ] Internacionalización (i18n)
- [ ] Tests unitarios y e2e
- [ ] PWA capabilities

## Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/nueva-caracteristica`)
3. Commit tus cambios (`git commit -m 'Agrega nueva característica'`)
4. Push a la rama (`git push origin feature/nueva-caracteristica`)
5. Abre un Pull Request

## Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.

---

**OlasApp** - Reportes de surf inteligentes para la comunidad surfista 🏄‍♂️